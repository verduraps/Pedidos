# Minimarket Pedidos — versión oscura

Subir estos archivos a la raíz del repositorio de GitHub Pages:

- index.html
- manifest.json
- sw.js
- icon-192.png
- icon-512.png

La versión usa fondo oscuro, letras blancas/plateadas y botones azules/verdes.
La impresión incluye claramente la **Fecha del pedido** (fecha para la que se prepara el pedido).

Importante: los datos siguen guardándose localmente en la SUNMI mediante localStorage.
